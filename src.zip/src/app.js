import React from 'react';
import NewExpense from './components/NewExpense/NewExpense';
import Expenses from "./components/Expenses/Expenses";


const App = (props)=> {

 let expenses = [
    {
      id:'e1',
      title: 'School fee',
      amount:250,
      date: new Date(2022, 5, 12)
    },

    {
      id:'e2',
      title: 'House Rent',
      amount:550,
      date: new Date(2022, 5, 10)
    },

    {
      id:'e3',
      title: 'Bike Service',
      amount:350,
      date: new Date(2022, 5, 15)
    },

    {
      id:'e4',
      title: 'Food',
      amount:400,
      date: new Date(2022, 5, 20)
    }

 ];


  return (
       <div>
      <NewExpense/>   
      <Expenses item =  {expenses}/> 
    </div>
  );
}
export default App;
